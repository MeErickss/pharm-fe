// SelectInputUpdate.jsx
import { useState, useEffect } from "react";
import api from "../../api";
import { SelectInputGeneric } from "./SelectInputGeneric";

export function SelectInputUpdate({ table, onChange, value = {} }) {
  const resourceMap = {
    grandeza: "grandeza",
    unidade: "unidade",
    status: "status",
    funcao: "funcao",
  };
  const endpoint = resourceMap[table] || table;

  const isCascade = table === "grandeza";

  const [options, setOptions] = useState([]);
  const [unidadeOptions, setUnidadeOptions] = useState([]);

  const [grandeza, setGrandeza] = useState(isCascade ? value.grandeza || "" : "");
  const [unidade, setUnidade] = useState(isCascade ? value.unidade || "" : "");
  const [selectedId, setSelectedId] = useState(!isCascade ? value?.[table] || "" : "");

  useEffect(() => {
    api
      .get(`/${endpoint}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      })
      .then(res => {
        if (typeof res.data[0] === 'string') {
          const mapped = res.data.map((item, idx) => ({ id: String(idx), nome: item }));
          setOptions(mapped);
        } else {
          setOptions(res.data);
        }
      })
      .catch(err => console.error(`Erro ao buscar opções para ${endpoint}:`, err));
  }, [endpoint]);

  useEffect(() => {
    if (isCascade && grandeza) {
      api
        .get("/unidade/porgrandeza", {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          params: { descricao: grandeza },
        })
        .then(res => {
          const mapped = res.data.map(u => ({
            id: u.id,
            descricao: u.unidade,
            abreviacao: u.abreviacao,
            status: u.status
          }));
          setUnidadeOptions(mapped);
          console.log("Unidades mapeadas:", mapped);
        })
        .catch(err => console.error(`Erro ao buscar unidades para ${grandeza}:`, err));
    } else {
      setUnidadeOptions([]);
      setUnidade("");
    }
  }, [isCascade, grandeza]);

  if (isCascade) {
    return (
      <div className="space-y-2">
        <SelectInputGeneric
          resource={endpoint}
          displayField="nome"
          valueField="id"
          selected={options.find(o => o.nome === grandeza)?.id ?? ""}
          onChange={obj => {
            const nome = obj?.nome ?? "";
            setGrandeza(nome);
            setUnidade("");
            onChange({ grandeza: nome, unidade: "" });
          }}
        />

        <SelectInputGeneric
          resource="unidade"
          displayField="descricao"
          valueField="id"
          optionsOverride={unidadeOptions}
          selected={unidadeOptions.find(u => u.descricao === unidade)?.id ?? ""}
          onChange={obj => {
            const nome = obj?.descricao ?? "";
            setUnidade(nome);
            onChange({ grandeza, unidade: nome });
          }}
        />
      </div>
    );
  }

  return (
    <SelectInputGeneric
      resource={endpoint}
      displayField={endpoint === "unidade" ? "descricao" : "nome"}
      valueField="id"
      selected={selectedId}
      onChange={obj => {
        const id = obj?.id ?? obj;
        setSelectedId(id);
        if (typeof obj === "object") onChange(obj);
        else onChange({ [table]: obj });
      }}
    />
  );
}
