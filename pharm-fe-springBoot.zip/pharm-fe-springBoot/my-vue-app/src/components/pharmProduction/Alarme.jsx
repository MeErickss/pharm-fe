export function Alarme(){
    return(
        <div className="flex flex-wrap w-full h-full justify-center items-center">
            <h1>Alarms</h1>
        </div>
    )
}