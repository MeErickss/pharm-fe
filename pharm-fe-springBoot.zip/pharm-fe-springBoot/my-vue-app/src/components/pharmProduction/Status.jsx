export function Status(){
    return(
        <div className="flex flex-wrap w-full h-full justify-center items-center">
            <h1>Status</h1>
        </div>
    )
}