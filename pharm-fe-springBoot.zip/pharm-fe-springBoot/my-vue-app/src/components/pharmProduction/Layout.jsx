import imagem from "./images/p.png"


export function Layout(){
    return(
        <div className="w-full h-full">
            <img src={imagem} alt="Produção"/>
        </div>
    )
}