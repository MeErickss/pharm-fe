export function StatusProducao(){
    return(
        <div className="flex flex-wrap w-full h-full justify-center items-center">
            <h1>ProductionStatus</h1>
        </div>
    )
}