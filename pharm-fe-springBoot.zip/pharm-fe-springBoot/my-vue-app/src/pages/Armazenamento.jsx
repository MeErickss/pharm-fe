export function Armazenamento() {
  return (
      <div className="flex-1 p-4 bg-gray-100">
        <h1 className="text-3xl font-bold mb-4">Armazenamento</h1>
        <p>Gerencie seus dados de armazenamento aqui.</p>
      </div>
  );
}
